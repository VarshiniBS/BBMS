# -*- coding: utf-8 -*-
"""
Created on Sun May 15 20:06:53 2022

@author: Home
"""

from tkinter import * #for gui
from tkinter import messagebox #for mesaage boxes
import mysql.connector
from userMod import *
import Admin
import InventoryMod
import TestingMod


def showDashboard(frame,sm=None):
    frame.destroy()
    dashboard = Tk()

    dashboard.geometry("1200x1200")
    dashboard.title("Admin Dashboard")

    for i in range(4):
        dashboard.columnconfigure(i,weight=15)

    dashboard.rowconfigure(0,weight=1)
    dashboard.rowconfigure(1,weight=10)
    dashboard.rowconfigure(2,weight=10)

    welcomeLabel = Label(dashboard,text="Welcome ",font=("Open Sans", 20))
    welcomeLabel.grid(row=0,column=0,sticky="NSEW")

    userModBtns = LabelFrame(dashboard,padx=2,pady=2,bg="#D3D3D3")
    inventoryModBtns =LabelFrame(dashboard,padx=2,pady=2,bg="#D3D3D3")
    reportMod = LabelFrame(dashboard,padx=2,pady=2,bg="#D3D3D3")

    userModBtns.grid(row=1,column=0,columnspan=2,sticky="nswe",padx=10,pady=10)
    inventoryModBtns.grid(row=1,column=2,columnspan=2,sticky="nsew",padx=10,pady=10)
    reportMod.grid(row=2,column=1,columnspan=2,sticky="nswe",padx=10,pady=10)

    for i in range(3):
        userModBtns.rowconfigure(i,weight=5)
        inventoryModBtns.rowconfigure(i,weight=5)
        reportMod.rowconfigure(i,weight=5)

    userModBtns.columnconfigure(0,weight=20)
    inventoryModBtns.columnconfigure(0,weight=20)
    reportMod.columnconfigure(0,weight=20)

    newUserBtn = Button(userModBtns ,text="Add New User",font=("Open Sans", 15),padx=2,pady=2,width=25,command = lambda:addNewUser(dashboard))
    updateBtn = Button(userModBtns ,text="Update User Info",font=("Open Sans", 15),padx=2,pady=2,width=25,command= lambda:showUpdateInfoBtns(dashboard))
    allUsersBtn = Button(userModBtns ,text="All Users",font=("Open Sans", 15),padx=2,pady=2,width=25,command= lambda:showUsers(dashboard))

    newUserBtn.grid(row=0,column=0)
    updateBtn.grid(row=1,column=0,columnspan=2)
    allUsersBtn.grid(row=2,column=0,columnspan=2)

    addBloodBtn = Button(inventoryModBtns,text="Add To BloodStock",font=("Open Sans", 15),padx=2,pady=2,width=25,command = lambda:InventoryMod.showAddToStockFrame(dashboard))
    viewInvBtn = Button(inventoryModBtns,text="View Inventory details ",font=("Open Sans", 15),padx=2,pady=2,width=25,command = lambda:InventoryMod.showInventoryOptions(dashboard))
    issueBtn = Button(inventoryModBtns,text="Issue",font=("Open Sans", 15),padx=2,pady=2,width=25,command = lambda:InventoryMod.showBloodgrpOptions(dashboard))

    addBloodBtn.grid(row=0,column=0,columnspan=2)
    viewInvBtn.grid(row=1,column=0,columnspan=2)
    issueBtn.grid(row=2,column=0,columnspan=2)


    fillReportBtn = Button(reportMod,text="Fill Test Report",font=("Open Sans", 15),padx=2,pady=2,width=25,command = lambda:TestingMod.showReportForm(dashboard))
    viewReportBtn = Button(reportMod,text="View Test Report",font=("Open Sans", 15),padx=2,pady=2,width=25,command = lambda:TestingMod.showReportDetails(dashboard))


    fillReportBtn.grid(row=1,column=0,columnspan=2)
    viewReportBtn.grid(row=2,column=0,columnspan=2)

    logoutBtn = Button(dashboard,text="Logout",font=("Open Sans", 20),padx=2,pady=2,command = lambda:Admin.logoutFunc(dashboard))
    logoutBtn.grid(row=0,column=2,sticky="e")

    dashboard.mainloop()


