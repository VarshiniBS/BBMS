# -*- coding: utf-8 -*-
"""
Created on Sun May 15 20:07:52 2022

@author: Home
"""

from tkinter import * #for gui
from tkinter import messagebox #for mesaage boxes
import tkcalendar
from tkinter import ttk
import mysql.connector
import newDashboard

mydb = mysql.connector.connect(
  host="localhost",
  user="",
  password="",
  database = ""

)

idVerified = False




def showReportForm(viewWindow):
    viewWindow.destroy()

    reportFrame = Tk()
    reportFrame.geometry("1900x1800")

    for i in range(10):
        reportFrame.rowconfigure(i,weight=3)
    reportFrame.columnconfigure(0,weight=3)
    reportFrame.columnconfigure(1,weight=5)
    reportFrame.columnconfigure(1,weight=3)

    pktIdLabel = Label(reportFrame,text="Blood Packet Id  *", font=("Arial", 13))
    testidLabel = Label(reportFrame,text="Blood Test Id  *", font=("Arial", 13))
    bloodgroupLabel = Label(reportFrame,text="Blood Group  *", font=("Arial", 13))
    rhLabel = Label(reportFrame,text="Rh Value  *", font=("Arial", 13))
    hbsLabel = Label(reportFrame,text="HBsAg  *", font=("Arial", 13))
    hivLabel = Label(reportFrame,text="HIV  *", font=("Arial", 13))
    testResultLabel = Label(reportFrame,text="Test Result  *", font=("Arial", 13))

    pktIdEntry = Entry(reportFrame,borderwidth=3,font=("Arial", 13),width=12)


    testIdEntry = Entry(reportFrame,borderwidth=3,font=("Arial", 13),width=12)


    getDetailsBtn = Button(reportFrame,text="GET PACKET DETAILS",font=("Arial", 15),activebackground="green",command = lambda:getPacketDetails(pktIdEntry.get(),reportFrame))
    getDetailsBtn.grid(row=0,column=2,pady=7)


    pktIdEntry.grid(row=0,column=1,sticky="W",pady=10)
    pktIdLabel.grid(row=0,column=0,sticky="WE",pady=7)
    testidLabel.grid(row=2,column=0,sticky="WE",pady=7)
    testIdEntry.grid(row=2,column=1,sticky="W",pady=10)
    bloodgroupLabel.grid(row=3,column=0,sticky="WE",pady=7)
    rhLabel.grid(row=4,column=0,sticky="WE",pady=7)
    hbsLabel.grid(row=5,column=0,sticky="WE",pady=7)
    hivLabel.grid(row=6,column=0,sticky="WE",pady=7)
    testResultLabel.grid(row=7,column=0,sticky="WE",pady=7)

    bloodgroupList =['A','B','AB','O']
    bloodgrpVar= StringVar()
    bloodgrpMenu = ttk.Combobox(reportFrame,textvariable=bloodgrpVar,values=bloodgroupList)

    rhList = ['+ve','-ve']
    rhVar = StringVar()
    rhMenu = ttk.Combobox(reportFrame,textvariable=rhVar,values=rhList)

    hivtestResultList =['POSITIVE','NEGATIVE']
    hbstestResultList = ['POSITIVE','NEGATIVE']
    testResultList = ['PASS','FAIL']

    hivVar = StringVar()
    hivMenu = ttk.Combobox(reportFrame,textvariable=hivVar,values=hivtestResultList)
    hbsVar = StringVar()
    hbsMenu = ttk.Combobox(reportFrame,textvariable=hbsVar,values=hbstestResultList)
    testVar = StringVar()
    testMenu = ttk.Combobox(reportFrame,textvariable=testVar,values=testResultList)

    bloodgrpMenu.grid(row=3,column=1,sticky="W",pady=10)
    rhMenu.grid(row=4,column=1,sticky="W",pady=10)
    hivMenu.grid(row=5,column=1,sticky="W",pady=10)
    hbsMenu.grid(row=6,column=1,sticky="W",pady=10)
    testMenu.grid(row=7,column=1,sticky="W",pady=10)



    submitBtn = Button(reportFrame,text="SUBMIT",font=("Arial", 15),activebackground="green",
                       command= lambda: addReportToDb(testIdEntry.get(),bloodgrpMenu.get(),rhMenu.get(),hbsMenu.get(),hivMenu.get(),testMenu.get()))
    submitBtn.grid(row=8,column=0,pady=10)

    backBtn = Button(reportFrame,text="BACK",font=("Arial", 15),padx=2,pady=2,command = lambda:newDashboard.showDashboard(reportFrame))
    backBtn.grid(row=9,column=0)

    reportFrame.mainloop()


def getPacketDetails(pktId,window):
    mycur = mydb.cursor()
    val ={"1":pktId}
    sql = '''select bp.bloodpktId
    from blood_packet bp
    where bp.bloodpktId = %(1)s and
    bp.bloodStatus = 'PENDING_TEST'
            ;
          '''
    mycur.execute(sql,val)
    pid = mycur.fetchone()
    print(pid)
    mycur.close()
    if pid==None:
        msg = "Pkt not found under pending test list"
        messagebox.showerror("Not Found",msg)
    else:
        mycur = mydb.cursor()
        val ={"1":"PENDING_TEST","2":pid[0]}

        sql = '''select  bt.testId,bp.bloodpktId, CONCAT(u.firstname," ",u.lastname),u.phone,bp.dateOfCollection
                from blood_packet bp join user u on bp.userId=u.userId join bloodtest bt on bt.bloodpktId = bp.bloodpktId
                where bp.bloodStatus = %(1)s  and bp.bloodpktId = %(2)s;'''

        mycur.execute(sql,val)
        data = mycur.fetchone()
        print(data)
        columns = ('testId','pktId','dname','dphone','Doc')
        tab = ttk.Treeview(window,column=columns,show='headings',selectmode='browse',height=1)
        tab.grid(row=1,column=0,columnspan=2)
        tab.heading('testId', text="Test_Id")
        tab.heading('pktId', text="Sample_Id")
        tab.heading('dname', text="Donor Name")
    #tab.heading('dlname', text="Donor LastName")
        tab.heading('dphone', text="Donor Phone")
        tab.heading('Doc', text="Date Of Collection")
        tab.insert("",END,values=data)

        global idVerified
        idVerified = True

        mycur.close()


def addReportToDb(testId,bloodgrp,rh,hbsResult,hivResult,testResult):
    val = {'1':int(testId),
           '2':bloodgrp,
           '3':rh,
           '4':hbsResult,
           '5':hivResult,
           '6':testResult}
    print(val)
    if idVerified:

        mycur = mydb.cursor()
        sql = '''insert into testreport(testId,groupingTest,rhTest,HBsAg,Hiv) values(%(1)s,%(2)s,%(3)s,%(4)s,%(5)s);'''

        try:
            mycur.execute(sql,val)
            mydb.commit()

            print("done")
            addStatusTodb(testId,testResult)
            #assignBloodgrp(testId,bloodgrp,rh)
            mycur.callproc('assignBloodgrp',(testId,bloodgrp,rh))
            #mycur.callproc('setBloodStatus',(testId,testResult,))
            #setStatus(testId,testResult)
            mydb.commit()
            mycur.close()
            messagebox.showinfo("Success","Report details were filled")
        except:
            messagebox.showerror("Error","Report was not filled")
    else:
        messagebox.showerror("Error","Please verify the packet Id")


'''def setStatus(testId,testResult):
    mycur = mydb.cursor()
    val ={"1":testId,"2":testResult}
    if testResult == "PASS":
       sql=' UPDATE blood_packet bp, bloodtest bt
           SET bp.bloodStatus = 'AVAILABLE'
           WHERE bt.testId = %(1)s AND
           bt.teststatus='PASS' AND
           bt.bloodpktId = bp.bloodpktId;'
       mycur.execute(sql,val)
       mydb.commit()
       mycur.close()
    else:
        sql = 'UPDATE blood_packet bp, bloodtest bt  SET bp.bloodStatus = 'TEST_FAILED'
 WHERE bt.testId = %(1)s AND
		bt.teststatus='FAIL' AND
        bt.bloodpktId = bp.bloodpktId;'
        mycur.execute(sql,val)
        mydb.commit()
        mycur.close()

        '''

def assignBloodgrp(testid,bloodgrp,rh):
    val1 = {'1':testid}
    sql1 = '''select bt.bloodpktId
            from bloodtest bt
            where bt.testId = %(1)s;'''
    mycur = mydb.cursor()
    mycur.execute(sql1,val1)
    pktid = mycur.fetchone()[0]
    val2 = {'1':bloodgrp, '2':rh, '3':pktid}
    sql2 = '''update blood_packet set bloodgroup=%(1)s, rhValue=%(2)s
            where bloodpktId = %(3)s ;'''
    mycur.execute(sql2,val2)
    mydb.commit()
    print("done")
    mycur.close()

def addStatusTodb(testid,testResult):
    mycur = mydb.cursor()
    val={'1':testid,'2':testResult}

    sql2 = '''update bloodtest set teststatus = %(2)s where testId = %(1)s;'''
    mycur.execute(sql2,val)
    print('done')
    mydb.commit()
    mycur.close()


def showReportDetails(mainWindow):
    mainWindow.destroy()
    reportFrame = Tk()
    reportFrame.geometry("800x800")


    reportFrame.rowconfigure(0,weight=3)
    reportFrame.rowconfigure(1,weight=30)
    reportFrame.rowconfigure(2,weight=3)

    reportFrame.columnconfigure(0,weight=3)
    reportFrame.columnconfigure(1,weight=5)
    reportFrame.columnconfigure(1,weight=3)

    pktIdLabel = Label(reportFrame,text="Blood Packet Id  *", font=("Arial", 13))
    pktIdEntry = Entry(reportFrame,borderwidth=3,font=("Arial", 13),width=12)

    pktIdEntry.grid(row=0,column=1,sticky="W",pady=10)
    pktIdLabel.grid(row=0,column=0,sticky="WE",pady=7)

    getDetailsBtn = Button(reportFrame,text="GET REPORT DETAILS",font=("Arial", 15),activebackground="green",command = lambda:getReportDetails(pktIdEntry.get(),reportFrame))
    getDetailsBtn.grid(row=0,column=2,pady=7)

    backBtn = Button(reportFrame,text="BACK",font=("Arial", 15),padx=2,pady=2,command = lambda:newDashboard.showDashboard(reportFrame))
    backBtn.grid(row=2,column=0)

    reportFrame.mainloop()


def getReportDetails(pktId,frame):
    mycur = mydb.cursor()
    val ={"1":pktId}
    sql = '''select bt.testId from bloodtest bt where bt.bloodpktId = %(1)s;'''
    mycur.execute(sql,val)
    tIdval1 = mycur.fetchone()
    mycur.close()
    if tIdval1 == None:
        messagebox.showerror("Error","Not a valid packet Id")
    else:
        mycur = mydb.cursor()
        sql = '''select testId from bloodtest bt

 where bt.bloodpktId = %(1)s and bt.teststatus  in ("PASS","FAIL");'''
        mycur.execute(sql,val)
        tIdval2 = mycur.fetchone()
        print(tIdval2)
        print("-------------")

        mycur.close()
        if tIdval2 == None:
            messagebox.showerror("Error","Test Report not filled yet")
        else:


            detFrame = LabelFrame(frame,padx=2,pady=2)
            detFrame.grid(row=1,column=0,columnspan=3)

            detFrame.columnconfigure(0,weight=4)
            detFrame.columnconfigure(0,weight=10)


            for i in range(6):
                detFrame.rowconfigure(0,weight=4)
            testIdLabel = Label(detFrame,text="Test Id  ", font=("Arial", 13))
            grpingTestLabel = Label(detFrame,text="Blood group", font=("Arial", 13))
            rhLabel = Label(detFrame,text="Rh", font=("Arial", 13))
            hivResLabel = Label(detFrame,text="HIV", font=("Arial", 13))
            hbsLabel = Label(detFrame,text="HBsAg", font=("Arial", 13))

            testIdLabel.grid(row=0,column=0,sticky="w")
            grpingTestLabel.grid(row=1,column=0,sticky="w")
            rhLabel.grid(row=2,column=0,sticky="w")
            hivResLabel.grid(row=3,column=0,sticky="w")
            hbsLabel.grid(row=4,column=0,sticky="w")

            tId = StringVar()
            grpVal = StringVar()
            rhVal = StringVar()
            hivVal  = StringVar()
            hbsVal  = StringVar()

            testId = Label(detFrame,textvariable=tId,padx=2,pady=2)
            grp = Label(detFrame,textvariable=grpVal,padx=2,pady=2)
            rh = Label(detFrame,textvariable=rhVal,padx=2,pady=2)
            hivRes = Label(detFrame,textvariable=hivVal,padx=2,pady=2)
            hbsRes = Label(detFrame,textvariable=hbsVal,padx=2,pady=2)

            testId.grid(row=0,column=1,sticky="e")
            grp.grid(row=1,column=1,sticky="e")
            rh.grid(row=2,column=1,sticky="e")
            hivRes.grid(row=3,column=1,sticky="e")
            hbsRes.grid(row=4,column=1,sticky="e")

            textBoxes = (testId,grp,rh,hivRes,hbsRes)
            val = {"1":pktId}
            mycur = mydb.cursor()
            sql = '''select r.testId , r.groupingTest, r.rhTest, r.HBsAg, r.Hiv
            from testreport r join bloodtest bt on r.testId = bt.testId
            where bt.bloodpktId =%(1)s;'''
            mycur.execute(sql,val)
            data = mycur.fetchone()

            tId.set(str(data[0]))
            grpVal.set(str(data[1]))
            rhVal.set(str(data[2]))
            hivVal.set(str(data[3]))
            hbsVal.set(str(data[4]))

            mycur.close()

