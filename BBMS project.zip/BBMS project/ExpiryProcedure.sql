DELIMITER &&
CREATE PROCEDURE setExpiryStatus()
BEGIN
 UPDATE blood_packet bp
 SET bp.bloodStatus = 'EXPIRED' 
 WHERE DATEDIFF(CURDATE(),bp.dateOfCollection)>=30  AND 
 (bp.bloodStatus = 'AVAILABLE' OR bp.bloodStatus = 'PENDING_TEST');

END &&


