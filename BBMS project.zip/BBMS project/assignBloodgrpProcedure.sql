DELIMITER &&
CREATE PROCEDURE assignBloodgrp(IN testid INT, IN bloodgrp varchar(2), IN rh varchar(3))
BEGIN

 UPDATE blood_packet bp join bloodtest bt on bp.bloodpktId = bt.bloodpktId join testreport t on bt.testId = t.testId
 SET bp.bloodgroup = bloodgrp, rhValue = rh
 WHERE bt.testId = testId AND
		bt.teststatus is not NULL ;

END &&


