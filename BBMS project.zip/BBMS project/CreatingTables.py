# -*- coding: utf-8 -*-
"""
Created on Sun May 15 20:10:11 2022

@author: Home
"""

import mysql.connector

mydb = mysql.connector.connect(
  host="localhost",
  user="",
  password=".",
  database = ""
)

print(mydb)
mycursor = mydb.cursor()
tab1 = '''CREATE TABLE User(
userid int NOT NULL AUTO_INCREMENT,
firstname varchar(255),
lastname varchar(255),
dob date,
phone char(10) NOT NULL UNIQUE,
loginid varchar(10),
login_pass varchar(10),
bloodgroup enum('A','B','AB','O'),
rhvalue enum('+ve','-ve'),
gender enum('M','F','OTHERS'),
CONSTRAINT pkuser PRIMARY KEY(userId));
'''
mycursor.execute(tab1)
mydb.commit()

tab2 = '''CREATE TABLE roles(
roleId int AUTO_INCREMENT,
roleName varchar(30),
CONSTRAINT pkroles PRIMARY KEY(roleId));

'''
mycursor.execute(tab2)
mydb.commit()

tab3 = '''CREATE TABLE user_roles(
userId int ,
roleId int,
CONSTRAINT pkuser_roles PRIMARY KEY(userId,roleId),
CONSTRAINT fk_userId FOREIGN KEY(userId) REFERENCES user(userid),
CONSTRAINT fk_roleId FOREIGN KEY(roleId) REFERENCES roles(roleId));



'''
mycursor.execute(tab3)
mydb.commit()


tab4 = '''CREATE TABLE blood_packet(
bloodpktId int AUTO_INCREMENT,
userId int NOT NULL,
bloodgroup enum('A','B','AB','O'),
rhValue enum('+ve','-ve'),
dateOfCollection date,
bloodStatus enum('PENDING_TEST','AVAILABLE','EXPIRED','TEST_FAILED','ISSUED'),
recvId int,
dateOfIssue date,
CONSTRAINT pkblood_pkt PRIMARY KEY(bloodpktId),
CONSTRAINT fkuserId FOREIGN KEY(userId) REFERENCES user(userId));

'''
mycursor.execute(tab4)
mydb.commit()


tab5 = '''CREATE TABLE bloodTest(
testId int AUTO_INCREMENT,
bloodpktId int NOT NULL,
teststatus enum('PASS','FAIL'),
sentForTestDate date,
CONSTRAINT pkbloodtest PRIMARY KEY(testId),
CONSTRAINT fkpktid FOREIGN KEY(bloodpktId) REFERENCES blood_packet(bloodpktId));
;

'''
mycursor.execute(tab5)
mydb.commit()


tab6 = '''CREATE TABLE testReport(
reportId int AUTO_INCREMENT,
testId int NOT NULL,
groupingTest  enum('A','B','AB','O') ,

rhTest  enum('+ve','-ve'),

HBsAg enum('POSITIVE','NEGATIVE'),
Hiv enum('POSITIVE','NEGATIVE'),
CONSTRAINT pkreport PRIMARY KEY(reportId),
CONSTRAINT fk_testId FOREIGN KEY(testId) REFERENCES bloodTest(testId));


'''
mycursor.execute(tab6)
mydb.commit()

adminInsert = '''insert into user(firstname,lastname,dob,phone,loginid,login_pass,bloodgroup,rhvalue,gender) values
 ("Sara","Lee",'1999-08-08','9900990099',"root","welcome","A","+ve","F");'''
mycursor.execute(adminInsert)
mydb.commit()

insertRoles1 = '''insert into roles(roleId, roleName) values (1,'Admin'); '''
insertRoles2 = '''insert into roles(roleId, roleName) values (2,'Donor'); '''
insertRoles3 = '''insert into roles(roleId, roleName) values (3,'Receiver'); '''

mycursor.execute(insertRoles1)
mydb.commit()

mycursor.execute(insertRoles2)
mydb.commit()

mycursor.execute(insertRoles3)
mydb.commit()

getUserId = '''select userid from user where phone = '9900990099'; '''
mycursor.execute(getUserId)
uid = mycursor.fetchone()
val = {"1" : uid, "2": 1 }
updateRole = '''insert into user_roles(userId, roleId) values (%(1)s, %(2)s ); '''
mycursor.execute(updateRole,val);
mydb.commit()




mycursor.close()

