# -*- coding: utf-8 -*-
"""
Created on Sun May 15 20:09:09 2022

@author: Home
"""

from tkinter import * #for gui
from tkinter import messagebox #for mesaage boxes
import tkcalendar
from tkinter import ttk
import mysql.connector
import newDashboard

mydb = mysql.connector.connect(
  host="localhost",
  user="",
  password="",
  database = ""

)


def addNewUser(dashboard):
    dashboard.destroy()
    form = Tk()
    form.geometry("800x650")
    form.rowconfigure(0,weight=70)
    form.rowconfigure(1,weight=3)

    form.columnconfigure(0,weight=300)

    formFrame = LabelFrame(form,padx=2,pady=2)
    formFrame.grid(row=0,column=0,sticky="NSEW")

    for i in range(10):
        formFrame.rowconfigure(i,weight=2)
    formFrame.columnconfigure(0,weight=3)
    formFrame.columnconfigure(1,weight=8)

    backBtn = Button(form,text="BACK",font=("Open Sans", 15),padx=2,pady=2,command = lambda:newDashboard.showDashboard(form))
    backBtn.grid(row=1,column=0)

    fNameLabel = Label(formFrame,text="First Name  *", font=("Open Sans", 13))
    lNameLabel = Label(formFrame,text="Last Name  *", font=("Open Sans", 13))
    phoneLabel = Label(formFrame,text="Phone Number  *", font=("Open Sans", 13))
    dobLabel = Label(formFrame,text="DOB  *", font=("Open Sans", 13))
    genderLabel = Label(formFrame,text="Gender  *", font=("Open Sans", 13))
    bloodgroupLabel = Label(formFrame,text="Blood Group  *", font=("Open Sans", 13))
    rhLabel = Label(formFrame,text="Rh Value  *", font=("Open Sans", 13))
    loginidLabel = Label(formFrame,text="Login Id", font=("Open Sans", 13))
    passLabel = Label(formFrame,text="Password", font=("Open Sans", 13))


    fNameLabel.grid(row=0,column=0,sticky="W",pady=7)
    lNameLabel.grid(row=1,column=0,sticky="W",pady=7)
    phoneLabel.grid(row=2,column=0,sticky="W",pady=7)
    dobLabel.grid(row=3,column=0,sticky="W",pady=7)
    genderLabel.grid(row=4,column=0,sticky="W",pady=7)
    bloodgroupLabel.grid(row=5,column=0,sticky="W",pady=7)
    rhLabel.grid(row=6,column=0,sticky="W",pady=7)
    loginidLabel.grid(row=7,column=0,sticky="W",pady=7)
    passLabel.grid(row=8,column=0,sticky="W",pady=7)

    fNameEntry = Entry(formFrame,borderwidth=3,font=("Open Sans", 13),width=40)
    lNameEntry = Entry(formFrame,borderwidth=3,font=("Open Sans", 13),width=40)
    phoneEntry = Entry(formFrame,borderwidth=3,font=("Open Sans", 13),width=12)
    idEntry = Entry(formFrame,borderwidth=3,font=("Open Sans", 13),width=20)
    passEntry = Entry(formFrame,borderwidth=3,font=("Open Sans", 13),width=20)

    dob = tkcalendar.DateEntry(formFrame,date_pattern="MM/dd/yyyy")

    genderList = ['M','F','OTHERS']
    genVar = StringVar()
    genMenu = ttk.Combobox(formFrame,textvariable=genVar,values=genderList)
    #btn = Button(formFrame,text="LOGIN",font=("Arial", 15),command=lambda:x(genVar.get()))
    #btn.grid(row=5,column=1)

    bloodgroupList =['A','B','AB','O']
    bloodgrpVar= StringVar()
    bloodgrpMenu = ttk.Combobox(formFrame,textvariable=bloodgrpVar,values=bloodgroupList)

    rhList = ['+ve','-ve']
    rhVar = StringVar()
    rhMenu = ttk.Combobox(formFrame,textvariable=rhVar,values=rhList)

    fNameEntry.grid(row=0,column=1,sticky="W",pady=10)
    lNameEntry.grid(row=1,column=1,sticky="W",pady=10)
    phoneEntry.grid(row=2,column=1,sticky="W",pady=10)
    dob.grid(row=3,column=1,sticky="W",pady=10)
    genMenu.grid(row=4,column=1,sticky="W",pady=10)
    bloodgrpMenu.grid(row=5,column=1,sticky="W",pady=10)
    rhMenu.grid(row=6,column=1,sticky="W",pady=10)
    idEntry.grid(row=7,column=1,sticky="W",pady=10)
    passEntry.grid(row=8,column=1,sticky="W",pady=10)

    submitBtn = Button(formFrame,text="SUBMIT",font=("Open Sans", 15),activebackground="green",
                       command = lambda:insertIntodb(fNameEntry.get(),lNameEntry.get(),phoneEntry.get(),str(dob.get_date()),genMenu.get(),bloodgrpMenu.get(),rhMenu.get(),form,idEntry.get(),passEntry.get()))
    submitBtn.grid(row=9,column=0,pady=7,sticky="W")


    form.mainloop()

def insertIntodb(fname,lname,phone,dob,gen,bloodgrp,rh,window,loId="",passwd=""):
    mycursor = mydb.cursor()
    if not(len(fname)!=0 and len(lname)!=0 and len(str(phone))!=0 and len(dob)!=0 and len(gen)!=0 and len(bloodgrp)!=0 and len(rh)!=0):
         messagebox.showerror("Error","Fields marked with * must be filled")
    if not(phone.isdigit()):
        messagebox.showerror("Error","Phone number should only contain digits")
    elif len(str(phone))!=10:

        messagebox.showerror("Error","phone number must be 10 digit number")
    else:
        val = {
            '1': fname,
            '2': lname,
            '3': dob,
            '4': phone,
            '5': loId,
            '6': passwd,
            '7': bloodgrp,
            '8': rh,
            '9': gen
            }
        print(val)
        yr,mon,dt = str(dob).split("-")

        sql = '''INSERT INTO user (firstname,lastname,dob,phone,loginid,login_pass,bloodgroup,rhvalue,gender)
        VALUES (%(1)s,%(2)s,%(3)s,%(4)s,%(5)s,%(6)s,%(7)s,%(8)s,%(9)s);'''

        try:
            mycursor.execute(sql,val)
            mydb.commit()
            messagebox.showinfo("Success","New User inserted")
            updateRole(window)

        except:
            mydb.rollback()
            messagebox.showerror("Error","There was an error")
        mycursor.close()

def updateRole(window):
    updateframe = LabelFrame(window)
    updateframe.grid(row=1,column=1,sticky="NSEW")
    updateframe.columnconfigure(0,weight=30)
    updateframe.rowconfigure(0,weight=20)
    upformFrame = Frame(updateframe,padx=2,pady=2)
    upformFrame.grid(row=0,column=0,sticky="NEW")
    for i in range(4):
        upformFrame.rowconfigure(i,weight=2)
    upformFrame.columnconfigure(0,weight=3)
    upformFrame.columnconfigure(1,weight=8)

    phoneLabel = Label(upformFrame,text="Phone Number  *", font=("Arial", 13))
    roleLabel = Label(upformFrame,text="Role  *", font=("Arial", 13))


    phoneEntry = Entry(upformFrame,borderwidth=3,font=("Arial", 13),width=12)

    roleList = ["Admin","Donor","Receiver"]
    roleVar = StringVar()
    roleMenu = ttk.Combobox(upformFrame,textvariable=roleVar,values=roleList)

    submitBtn = Button(upformFrame,text="SUBMIT",font=("Arial", 15),activebackground="green",
                       command = lambda:insertRoleIntodb(phoneEntry.get(),roleMenu.get()))

    phoneLabel.grid(row=0,column=0,sticky="WE",pady=10)
    roleLabel.grid(row=2,column=0,sticky="WE",pady=10)

    phoneEntry.grid(row=0,column=1,sticky="W",pady=15)
    roleMenu.grid(row=2,column=1,sticky="W",pady=15)

    submitBtn.grid(row=3,column=0,pady=7)
    updateframe.mainloop()

def insertRoleIntodb(phone,role):
    if phone.isdigit() and len(phone)==10:
        mycur = mydb.cursor()
        sql1 = '''select userid from user u where u.phone=%(1)s;'''
        val1 = {'1':phone,'2':role}
        mycur.execute(sql1,val1)
        uid = mycur.fetchone()[0]
        if uid==None:
            messagebox.showerror("Not Found"," User not found")
        else:
            sql2 = '''select firstname,lastname
            from user u
            where u.phone=%(1)s;'''
            mycur.execute(sql2,val1)
            data = mycur.fetchone()
            sql3 = '''select roleId from roles r where r.roleName=%(2)s;'''
            mycur.execute(sql3,val1)
            rid = mycur.fetchone()[0]
            val2 = {'1':uid,'2':rid}
            sql4 = '''insert into user_roles(userId,roleId) values(%(1)s,%(2)s);'''
            mycur.execute(sql4,val2)
            mydb.commit()
            mycur.close()
            messagebox.showinfo("Success","Role of "+" ".join(data)+" updated to "+role)
    else:
        messagebox.showerror("Error","Not a valid phone number")

def showUpdateInfoBtns(window):
    window.destroy()
    frame = Tk()
    frame.geometry("1900x1800")
    #frame = LabelFrame(window,padx=2,pady=2)
    #frame.grid(row=1,column=1,sticky="NSEW")
    frame.rowconfigure(0,weight=2)
    frame.rowconfigure(1,weight=40)
    frame.rowconfigure(2,weight=2)
    frame.columnconfigure(0,weight=10)
    frame.columnconfigure(1,weight=10)


    formFrame = Frame(frame,padx=2,pady=2)
    formFrame.grid(row=1,column=0,columnspan=2,sticky="NSWE")
    formFrame.rowconfigure(0,weight=1)
    formFrame.rowconfigure(1,weight=50)
    formFrame.columnconfigure(0,weight=1)
    formFrame.columnconfigure(1,weight=50)

    backBtn = Button(frame,text="BACK",font=("Arial", 15),padx=2,pady=2,command = lambda:newDashboard.showDashboard(frame))
    backBtn.grid(row=2,column=0)

    upPerInfoBtn = Button(frame,text="Personal Details",font=("Arial", 15),command = lambda: takePhoneNo(formFrame))
    upRoleInfoBtn = Button(frame,text="Role",font=("Arial", 15),command=lambda:updateRole(formFrame))

    upPerInfoBtn.grid(row=0,column=0)
    upRoleInfoBtn.grid(row=0,column=1)

def takePhoneNo(frame):
    f1 = Frame(frame,padx=1,pady=1)
    f1.grid(row=1,column=1,sticky="NSEW")
    f1.rowconfigure(0,weight=3)
    f1.rowconfigure(1,weight=50)
    f1.columnconfigure(0,weight=2)
    f1.columnconfigure(1,weight=3)
    f1.columnconfigure(2,weight=4)

    phoneLabel = Label(f1,text="Phone Number  *", font=("Arial", 13))
    phoneEntry = Entry(f1,borderwidth=3,font=("Arial", 13),width=12)
    getDetailsBtn = Button(f1,text="GET DETAILS",font=("Arial", 13),activebackground="green",command = lambda:getDetails(f1,phoneEntry.get()))


    phoneLabel.grid(row=0,column=0,sticky="WE",pady=7)
    phoneEntry.grid(row=0,column=1,sticky="W",pady=10)
    getDetailsBtn.grid(row=0,column=2,pady=7,sticky="W")


def getDetails(mainFrame,ph):
    if ph.isdigit() and len(ph)==10:
        val = {"1":ph}
        try:
            mycur = mydb.cursor()
            sql1 = '''select firstname,lastname,dob,phone,loginid,login_pass,bloodgroup,rhvalue,gender,userid
                from user u
                where u.phone=%(1)s;'''
            mycur.execute(sql1,val)
            data = mycur.fetchone()
            mycur.close()
            if data==None:
                messagebox.showerror("Error","Phone number not in database")
            else:
                print(data)
                y,m,d = str(data[2]).split("-")
                formFrame = Frame(mainFrame,padx=1,pady=1)
                formFrame.grid(row=1,column=0,columnspan=3)

                for i in range(10):
                    formFrame.rowconfigure(i,weight=2)
                formFrame.columnconfigure(0,weight=3)
                formFrame.columnconfigure(1,weight=8)

                fNameLabel = Label(formFrame,text="First Name  *", font=("Arial", 13))
                lNameLabel = Label(formFrame,text="Last Name  *", font=("Arial", 13))
                phoneLabel = Label(formFrame,text="Phone Number  *", font=("Arial", 13))
                dobLabel = Label(formFrame,text="DOB  *", font=("Arial", 13))
                genderLabel = Label(formFrame,text="Gender  *", font=("Arial", 13))
                bloodgroupLabel = Label(formFrame,text="Blood Group  *", font=("Arial", 13))
                rhLabel = Label(formFrame,text="Rh Value  *", font=("Arial", 13))
                loginidLabel = Label(formFrame,text="Login Id", font=("Arial", 13))
                passLabel = Label(formFrame,text="Password", font=("Arial", 13))


                fNameLabel.grid(row=0,column=0,sticky="WE",pady=7)
                lNameLabel.grid(row=1,column=0,sticky="WE",pady=7)
                phoneLabel.grid(row=2,column=0,sticky="WE",pady=7)
                dobLabel.grid(row=3,column=0,sticky="WE",pady=7)
                genderLabel.grid(row=4,column=0,sticky="WE",pady=7)
                bloodgroupLabel.grid(row=5,column=0,sticky="WE",pady=7)
                rhLabel.grid(row=6,column=0,sticky="WE",pady=7)
                loginidLabel.grid(row=7,column=0,sticky="WE",pady=7)
                passLabel.grid(row=8,column=0,sticky="WE",pady=7)

                fNameEntry = Entry(formFrame,borderwidth=3,font=("Arial", 13),width=40)
                fNameEntry.insert(0,data[0])

                lNameEntry = Entry(formFrame,borderwidth=3,font=("Arial", 13),width=40)
                lNameEntry.insert(0,data[1])

                phoneEntry = Entry(formFrame,borderwidth=3,font=("Arial", 13),width=12)
                phoneEntry.insert(0,data[3])

                idEntry = Entry(formFrame,borderwidth=3,font=("Arial", 13),width=20)
                idEntry.insert(0,data[4])

                passEntry = Entry(formFrame,borderwidth=3,font=("Arial", 13),width=20)
                passEntry.insert(0,data[5])

                dob = tkcalendar.DateEntry(formFrame,date_pattern="MM/dd/yyyy",year=int(y),month=int(m),day=int(d))

                bloodgroupList =['A','B','AB','O']
                bloodgrpVar= StringVar()

                bloodgrpVar.set(data[6])
                bloodgrpMenu = ttk.Combobox(formFrame,textvariable=bloodgrpVar,values=bloodgroupList,state='readonly')


                rhList = ['+ve','-ve']
                rhVar = StringVar()
                x= rhList.index(data[7])
                rhMenu = ttk.Combobox(formFrame,textvariable=rhVar,values=rhList)
                rhMenu.current(newindex=x)


                genderList = ['M','F','OTHERS']
                genVar = StringVar()
                genMenu = ttk.Combobox(formFrame,textvariable=genVar,values=genderList)
                genMenu.set(data[8])

                fNameEntry.grid(row=0,column=1,sticky="W",pady=10)
                lNameEntry.grid(row=1,column=1,sticky="W",pady=10)
                phoneEntry.grid(row=2,column=1,sticky="W",pady=10)
                dob.grid(row=3,column=1,sticky="W",pady=10)
                genMenu.grid(row=4,column=1,sticky="W",pady=10)
                bloodgrpMenu.grid(row=5,column=1,sticky="W",pady=10)
                rhMenu.grid(row=6,column=1,sticky="W",pady=10)
                idEntry.grid(row=7,column=1,sticky="W",pady=10)
                passEntry.grid(row=8,column=1,sticky="W",pady=10)

                submitBtn = Button(formFrame,text="SUBMIT",font=("Arial", 15),activebackground="green",
                       command = lambda:updateInDb(fNameEntry.get(),lNameEntry.get(),phoneEntry.get(),str(dob.get_date()),genMenu.get(),bloodgrpMenu.get(),rhMenu.get(),data[9],idEntry.get(),passEntry.get()))
                submitBtn.grid(row=9,column=0,pady=7)
                formFrame.mainloop()
        except:
                messagebox.showerror("Error","There was an error")
    else:
        messagebox.showerror("Error","Not a valid phone number")


def updateInDb(fname,lname,phone,dob,gen,bloodgrp,rh,uid,loId="",passwd=""):
    print(fname,lname,phone,dob,gen,bloodgrp,rh,loId,passwd)
    try:
        val =  {
            '1': fname,
            '2': lname,
            '3': dob,
            '4': phone,
            '5': loId,
            '6': passwd,
            '7': bloodgrp,
            '8': rh,
            '9': gen,
            '10':uid
            }
        mycur = mydb.cursor()
        sql = '''update user
            set firstname= %(1)s, lastname=%(2)s, dob = %(3)s, phone = %(4)s, loginid = %(5)s, login_pass = %(6)s,
            bloodgroup = %(7)s, rhvalue =%(8)s, gender = %(9)s
            where user.userid=%(10)s;'''
        mycur.execute(sql,val)
        mydb.commit()
        mycur.close()
        messagebox.showinfo("Updated","Information updated")
    except:
        messagebox.showerror("Error","There was an error")


def showUsers(mainWindow):
    mainWindow.destroy()
    mycur=mydb.cursor()
    sql = '''select firstname,lastname,dob,phone,gender,bloodgroup,rhvalue,loginid,login_pass
    from user;'''
    mycur.execute(sql)
    data = mycur.fetchall()
    mycur.close()

    frame = Tk()
    frame.geometry("1000x800")
    frame.rowconfigure(0,weight=90)
    frame.rowconfigure(1,weight=3)


    tabFrame = LabelFrame(frame,padx=2,pady=2)

    tabFrame.rowconfigure(0,weight=3)
    tabFrame.rowconfigure(1,weight=3)
    #searchResultFrame = LabelFrame(tabFrame,padx=2,pady=2)
    #searchResultFrame.grid(row=1,column=0,columnspan=3,sticky="nswe")
    tabFrame.rowconfigure(2,weight=75)
    for i in range(3):
        tabFrame.columnconfigure(i,weight=5)
    tabFrame.grid(row=0,column=0,sticky="NSEW")

    backBtn = Button(frame,text="BACK",font=("Arial", 15),padx=2,pady=2,command = lambda:newDashboard.showDashboard(frame))
    backBtn.grid(row=1,column=0)

    searchLabel = Label(tabFrame,text="Search by Phone  *", font=("Arial", 13))
    searchLabel.grid(row=0,column=0,sticky="W")

    phoneEntry = Entry(tabFrame,borderwidth=3,font=("Open Sans", 13),width=12)
    phoneEntry.grid(row=0,column=1)

    searchBtn = Button(tabFrame,text="SEARCH",font=("Arial", 15),activebackground="green",command = lambda:getUserDetails(tabFrame,phoneEntry.get()))
    searchBtn.grid(row=0,column=2,sticky="E")

    style = ttk.Style()
    #Pick a theme
    style.theme_use("clam")
    # Configure our treeview colors

    style.configure("Treeview",
	background="#D3D3D3",
	foreground="black",
	rowheight=25,
	fieldbackground="#D3D3D3",
    font = ("Arial", 10),
    anchor = "center"
	)
# Change selected color
    style.map('Treeview',
	background=[('selected', 'green')])


    columns = ('fname','lname','dob','ph','gen','blg','rh','lid','lpass')
    tree = ttk.Treeview(tabFrame,column=columns,show='headings',selectmod='none')
    tree.heading('fname', text="First Name")
    tree.heading('lname', text="Last Name")
    tree.heading('ph', text="Phone")
    tree.heading('dob', text="Date of Birth(YYYY/MM/DD)")
    tree.heading('gen', text="Gender")
    tree.heading('blg', text="Blood Group")
    tree.heading('rh', text="Rh Value")
    tree.heading('lid', text="Login Id")
    tree.heading('lpass', text="Login Password")
    for i in columns:
        tree.column(i,anchor="center",width=140)
    for i in data:
        tree.insert("",END,values=i)
    tree.grid(row=2,column=0,columnspan=3,sticky="nswe")

    frame.mainloop()

def getUserDetails(frame,phone):
    if phone.isdigit() and len(phone)==10:
        mycur = mydb.cursor()
        sql1 = '''select userid from user u where u.phone=%(1)s;'''
        val1 = {'1':phone}
        mycur.execute(sql1,val1)
        uid = mycur.fetchone()
        mycur.close()
        if uid==None:
            messagebox.showerror("Not Found"," User not found")
        else:

            mycur = mydb.cursor()
            val = {"1":phone}
            sql =  '''select firstname,lastname,dob,phone,gender,bloodgroup,rhvalue,loginid,login_pass
            from user where phone=%(1)s;'''
            mycur.execute(sql,val)
            data = mycur.fetchone()
            mycur.close()
            style = ttk.Style()
            #Pick a theme
            style.theme_use("clam")
            # Configure our treeview colors

        style.configure("Treeview",
	background="#D3D3D3",
	foreground="black",
	rowheight=25,
	fieldbackground="#D3D3D3",
    font = ("Arial", 10),
    anchor = "center"
	)
# Change selected color
        style.map('Treeview',
	background=[('selected', 'green')])


        columns = ('fname','lname','dob','ph','gen','blg','rh','lid','lpass')
        tree = ttk.Treeview(frame,column=columns,show='headings',selectmod='none',height=1)
        tree.heading('fname', text="First Name")
        tree.heading('lname', text="Last Name")
        tree.heading('ph', text="Phone")
        tree.heading('dob', text="Date of Birth(YYYY/MM/DD)")
        tree.heading('gen', text="Gender")
        tree.heading('blg', text="Blood Group")
        tree.heading('rh', text="Rh Value")
        tree.heading('lid', text="Login Id")
        tree.heading('lpass', text="Login Password")
        for i in columns:
            tree.column(i,anchor="center",width=140)

        tree.insert("",END,values=data)
        tree.grid(row=1,column=0,columnspan=3,sticky="nswe",padx=10,pady=10)
    else:
        messagebox.showerror("Error","Not a valid phone number")


