# -*- coding: utf-8 -*-
"""
Created on Sun May 15 20:06:07 2022

@author: Home
"""

from tkinter import * #for gui
from tkinter import messagebox #for mesaage boxes
import tkcalendar
from tkinter import ttk
import mysql.connector
import newDashboard

mydb = mysql.connector.connect(
  host="localhost",
  user="",
  password="",
  database = ""

)

donorVerified = False
receiverVerified = False

def showAddToStockFrame(dashboard):
    dashboard.destroy()
    formFrame = Tk()
    formFrame.geometry("1900x1800")
    #formFrame.grid(row=1,column=1,sticky="NSWE")

    formFrame.rowconfigure(0,weight=2)
    formFrame.rowconfigure(1,weight=3)
    formFrame.rowconfigure(2,weight=2)
    formFrame.rowconfigure(3,weight=2)
    formFrame.rowconfigure(4,weight=2)

    for i in range(3):
       formFrame.columnconfigure(i,weight=3)

    phoneLabel = Label(formFrame,text=" Donor Phone Number  *", font=("Arial", 13))
    phoneLabel.grid(row=0,column=0,sticky="WE",pady=7)

    phoneEntry = Entry(formFrame,borderwidth=3,font=("Arial", 13),width=12)
    phoneEntry.grid(row=0,column=1,sticky="W",pady=10)

    getDetailsBtn = Button(formFrame,text="GET DONOR DETAILS",font=("Arial", 15),activebackground="green",command = lambda:getUserDetails(phoneEntry.get(),formFrame,'Donor'))
    getDetailsBtn.grid(row=0,column=2,pady=7,sticky="W")

    docLabel = Label(formFrame,text="Date Of Collection  *", font=("Arial", 13))
    docLabel.grid(row=2,column=0,sticky="WE",pady=7)

    doc = tkcalendar.DateEntry(formFrame,date_pattern="MM/dd/yyyy")
    doc.grid(row=2,column=1,sticky="W",pady=10)

    addBtn = Button(formFrame,text="ADD",font=("Arial", 15),activebackground="green",
                    command = lambda:addToStock(phoneEntry.get(),str(doc.get_date())))
    addBtn.grid(row=3,column=0,pady=7)

    backBtn = Button(formFrame,text="BACK",font=("Arial", 15),padx=2,pady=2,command = lambda:newDashboard.showDashboard(formFrame))
    backBtn.grid(row=4,column=0)

    formFrame.mainloop()


def getUserDetails(ph,window,role):
    mycur = mydb.cursor()
    val ={"1":ph,'2':role}
    sql = '''select firstname,lastname,dob,gender
            from user u join user_roles ur on u.userid=ur.userId join roles r on ur.roleId = r.roleId
            where u.phone = %(1)s and r.roleName=%(2)s;
          '''
    mycur.execute(sql,val)
    data = mycur.fetchone()
    mycur.close()
    if data==None:
        msg = "Number not found under" + role +" list"
        messagebox.showerror("Not Found",msg)
    else:

        columns = ('fname','lname','dob','gen')
        detailsTab = ttk.Treeview(window,column=columns,show='headings',height=1)
        detailsTab.grid(row=1,column=0,columnspan=3,sticky="N")
        detailsTab.heading('fname', text="First Name")
        detailsTab.heading('lname', text="Last Name")
        detailsTab.heading('dob', text="DOB(MM/DD/YYYY)")
        detailsTab.heading('gen', text="Gender")
        detailsTab.insert("",END,values=data)

        if role=='Donor':
            global donorVerified
            donorVerified = True
        if role=='Receiver':
            global receiverVerified
            receiverVerified = True
        #global verified
        #verified = True

def addToStock(ph,doc):
    print(donorVerified)
    if donorVerified:
         mycur = mydb.cursor()
         val ={"1":ph}
         sql = '''select u.userId
            from user u join user_roles ur on u.userid=ur.userId join roles r on ur.roleId = r.roleId
            where u.phone = %(1)s and roleName='Donor';
          '''
         mycur.execute(sql,val)
         uid = mycur.fetchone()[0]
         print(uid)
         val2 = {'1':int(uid),'2':doc,'3':"PENDING_TEST"}
         sql2 = '''insert into blood_packet(userId,dateOfCollection,bloodStatus) values(%(1)s,%(2)s,%(3)s);'''
         mycur.execute(sql2,val2)
         print(mycur.rowcount, "record inserted.")
         mydb.commit()
         mycur.execute('select last_insert_id();')
         pktId = mycur.fetchone()[0]
         sql3 = '''insert into bloodtest(bloodpktId,sentForTestDate) values(%(1)s,%(2)s);'''
         val3 ={'1':pktId,'2':doc}
         mycur.execute(sql3,val3)
         mydb.commit()
         mycur.close()
         messagebox.showinfo("Success","Details Entered\nSample sent for Testing")
    else:
         messagebox.showerror("Error"," Please verify the phone Number")

def showBloodgrpOptions(mainWindow):
    mainWindow.destroy()
    btnFrame = Tk()
    btnFrame.configure(background='#D3D3D3')
    btnFrame.geometry("1700x1700")

    for i in range(3):
        btnFrame.rowconfigure(i,weight=5)
    for i in range(4):
        btnFrame.columnconfigure(i,weight=5)

    a_pos = StringVar()
    a_pos.set("A +ve")
    a_pos_btn = Button(btnFrame,textvariable=a_pos,font=("Arial", 25),activebackground="green",command = lambda:showAvailableBlood(btnFrame,a_pos.get()))

    b_pos = StringVar()
    b_pos.set("B +ve")
    b_pos_btn = Button(btnFrame,textvariable=b_pos,font=("Arial", 25),activebackground="green",command = lambda:showAvailableBlood(btnFrame,b_pos.get()))

    ab_pos = StringVar()
    ab_pos.set("AB +ve")
    ab_pos_btn = Button(btnFrame,textvariable=ab_pos,font=("Arial", 25),activebackground="green",command = lambda:showAvailableBlood(btnFrame,ab_pos.get()))

    o_pos = StringVar()
    o_pos.set("O +ve")
    o_pos_btn = Button(btnFrame,textvariable=o_pos,font=("Arial", 25),activebackground="green",command = lambda:showAvailableBlood(btnFrame,o_pos.get()))

    a_neg = StringVar()
    a_neg.set("A -ve")
    a_neg_btn = Button(btnFrame,textvariable=a_neg,font=("Arial", 25),activebackground="green",command = lambda:showAvailableBlood(btnFrame,a_neg.get()))

    b_neg = StringVar()
    b_neg.set("B -ve")
    b_neg_btn = Button(btnFrame,textvariable=b_neg,font=("Arial", 25),activebackground="green",command = lambda:showAvailableBlood(btnFrame,b_neg.get()))

    ab_neg = StringVar()
    ab_neg.set("AB -ve")
    ab_neg_btn = Button(btnFrame,textvariable=ab_neg,font=("Arial", 25),activebackground="green",command = lambda:showAvailableBlood(btnFrame,ab_neg.get()))

    o_neg = StringVar()
    o_neg.set("O -ve")
    o_neg_btn = Button(btnFrame,textvariable=o_neg,font=("Arial", 25),activebackground="green",command = lambda:showAvailableBlood(btnFrame,o_neg.get()))

    a_pos_btn.grid(row=0,column=0,padx=2,pady=2,sticky="WE",ipady=15)
    b_pos_btn.grid(row=0,column=1,padx=2,pady=2,sticky="WE",ipady=15)
    ab_pos_btn.grid(row=0,column=2,padx=2,pady=2,sticky="WE",ipady=15)
    o_pos_btn.grid(row=0,column=3,padx=2,pady=2,sticky="WE",ipady=15)
    a_neg_btn.grid(row=1,column=0,padx=2,pady=2,sticky="WE",ipady=15)
    b_neg_btn.grid(row=1,column=1,padx=2,pady=2,sticky="WE",ipady=15)
    ab_neg_btn.grid(row=1,column=2,padx=2,pady=2,sticky="WE",ipady=15)
    o_neg_btn.grid(row=1,column=3,padx=2,pady=2,sticky="WE",ipady=15)

    backBtn = Button(btnFrame,text="BACK",font=("Arial", 15),padx=2,pady=2,command = lambda:newDashboard.showDashboard(btnFrame))
    backBtn.grid(row=3,column=0,sticky="NW")

    btnFrame.mainloop()

def showAvailableBlood(mainWindow,choice):
    mainWindow.destroy()
    viewFrame = Tk()
    viewFrame.configure(background="#D3D3D3")
    viewFrame.geometry("1700x1700")
    bloodgrp,rh = choice.split(" ")
    val = {'1':bloodgrp,'2':rh}

    viewFrame.rowconfigure(0,weight=30)
    viewFrame.rowconfigure(1,weight=10)
    viewFrame.rowconfigure(2,weight=10)
    viewFrame.columnconfigure(0,weight=100)
    tabFrame = Frame(viewFrame,padx=2,pady=2,bg="#D3D3D3")

    tabFrame.grid(row=0,column=0,sticky="NSWE")

    mycur = mydb.cursor()
    sql = '''select bp.bloodpktId, CONCAT(u.firstname," ",u.lastname) as donorName,CONCAT(bp.bloodgroup," ",bp.rhValue) as bloodgrp,
    bp.dateOfCollection
            from blood_packet bp join user u on bp.userId=u.userId
            where bp.bloodgroup=%(1)s and
                bp.rhValue=%(2)s and
                bp.bloodStatus = 'AVAILABLE'

                order by bp.dateOfCollection
                ;'''
    mycur.execute(sql,val)
    data = mycur.fetchall()
    mycur.close()

    style = ttk.Style()
    #Pick a theme
    style.theme_use("clam")
    # Configure our treeview colors

    style.configure("Treeview",

	foreground="black",
	rowheight=25,

    font = ("Arial", 10),
    anchor = "center"
	)
# Change selected color
    style.map('Treeview',
	background=[('selected', 'green')])

    columns = ('pktId','dname','bloodgrp','Doc')
    tab = ttk.Treeview(tabFrame,column=columns,show='headings',selectmode='browse')
    tab.heading('pktId', text="Packet_Id")
    tab.heading('dname', text="Donor Name")
    tab.heading('bloodgrp', text="Blood group")
    tab.heading('Doc', text="Date Of Collection")

    for i in data:
        tab.insert("",END,values=i,iid=str(i[0]))


    scrollbar = ttk.Scrollbar(tabFrame, orient=VERTICAL, command=tab.yview)
    tab.configure(yscroll=scrollbar.set)
    scrollbar.grid(row=0, column=1, sticky='ns')

    tab.grid(row=0,column=0,sticky="NSWE")

    issueBtn = Button(viewFrame,text="ISSUE",font=("Arial", 15),activebackground="green",command= lambda:showIssueForm(viewFrame,tab.focus(),tab))
    issueBtn.grid(row=1,column=0,sticky="NW")

    backBtn = Button(viewFrame,text="BACK",font=("Arial", 15),padx=2,pady=2,command = lambda:showBloodgrpOptions(viewFrame))
    backBtn.grid(row=2,column=0,sticky="NW")

    viewFrame.mainloop()

def showIssueForm(mainWindow,rowId,tab):
    mainWindow.destroy()
    print(rowId)
    #data = tab.item(rowId,'values')
    #print(data)
    pktid = int(rowId)
    print(type(pktid))
    formFrame = Tk()
    formFrame.geometry("1700x1700")

    formFrame.rowconfigure(0,weight=2)
    formFrame.rowconfigure(1,weight=3)
    formFrame.rowconfigure(2,weight=2)
    formFrame.rowconfigure(3,weight=2)
    formFrame.rowconfigure(4,weight=2)

    for i in range(3):
       formFrame.columnconfigure(i,weight=3)

    phoneLabel = Label(formFrame,text=" Receiver Phone Number  *", font=("Arial", 13))
    phoneLabel.grid(row=0,column=0,sticky="WE",pady=7)

    phoneEntry = Entry(formFrame,borderwidth=3,font=("Arial", 13),width=12)
    phoneEntry.grid(row=0,column=1,sticky="W",pady=10)

    getDetailsBtn = Button(formFrame,text="GET RECEIVER DETAILS",font=("Arial", 15),activebackground="green",command = lambda:getUserDetails(phoneEntry.get(),formFrame,'Receiver'))
    getDetailsBtn.grid(row=0,column=2,pady=7)

    doiLabel = Label(formFrame,text="Date Of Issue  *", font=("Arial", 13))
    doiLabel.grid(row=2,column=0,sticky="WE",pady=7)

    doi = tkcalendar.DateEntry(formFrame,date_pattern="MM/dd/yyyy")
    doi.grid(row=2,column=1,sticky="W",pady=10)

    fillBtn = Button(formFrame,text="SUBMIT",font=("Arial", 15),activebackground="green",
                    command = lambda:addReceiverDetTodb(pktid,phoneEntry.get(),str(doi.get_date())))
    fillBtn.grid(row=3,column=0,pady=7)

    backBtn = Button(formFrame,text="BACK",font=("Arial", 15),padx=2,pady=2,command = lambda:showBloodgrpOptions(formFrame))
    backBtn.grid(row=4,column=0)

    formFrame.mainloop()

def addReceiverDetTodb(pktid,ph,doi):
    print(receiverVerified)
    if receiverVerified:
         mycur = mydb.cursor()
         mydb.commit()
         val ={"1":ph}
         sql = '''select u.userId
            from user u join user_roles ur on u.userid=ur.userId join roles r on ur.roleId = r.roleId
            where u.phone = %(1)s and roleName='Receiver';
          '''
         mycur.execute(sql,val)
         uid = mycur.fetchone()[0]
         print(uid)

         val2 = {'1':pktid,'2':int(uid),'3':doi}
         sql2 = '''update blood_packet set recvId= %(2)s, dateOfIssue=%(3)s, bloodStatus = 'ISSUED'
                     where bloodpktId = %(1)s;'''
         mycur.execute(sql2,val2)
         print(mycur.rowcount, "record inserted.")
         mydb.commit()

         mycur.close()
         messagebox.showinfo("Success","Details Entered\n")
    else:
         messagebox.showerror("Error"," Please verify the phone Number")

def showInventoryOptions(window):
    window.destroy()

    btnFrame = Tk()
    btnFrame.geometry("1700x1700")

    btnFrame.rowconfigure(0,weight=4)
    btnFrame.rowconfigure(1,weight=40)
    btnFrame.rowconfigure(2,weight=40)

    tabFrame = LabelFrame(btnFrame,padx=2,pady=2)
    tabFrame.grid(row=1,column=0,columnspan=30)

    for i in range(4):
        btnFrame.columnconfigure(i,weight=4)

    pending_test_var = StringVar()
    pending_test_var.set('PENDING_TEST')
    pendingTestBtn = Button(btnFrame,textvariable=pending_test_var,font=("Arial", 25),activebackground="green",command = lambda:showBloodDetails(tabFrame,pending_test_var.get()))

    av_var = StringVar()
    av_var.set('AVAILABLE')
    avBtn = Button(btnFrame,textvariable=av_var,font=("Arial", 25),activebackground="green",command = lambda:showBloodDetails(tabFrame,av_var.get()))


    waste_var = StringVar()
    waste_var.set("WASTE BLOOD")
    wasteBtn = Button(btnFrame,textvariable=waste_var,font=("Arial", 25),activebackground="green",command = lambda:showBloodDetails(tabFrame,waste_var.get()))


    issued_var = StringVar()
    issued_var.set('ISSUED')
    issuedBtn = Button(btnFrame,textvariable=issued_var,font=("Arial", 25),activebackground="green",command = lambda:showBloodDetails(tabFrame,issued_var.get()))

    pendingTestBtn.grid(row=0,column=0)
    avBtn.grid(row=0,column=1)
    wasteBtn.grid(row=0,column=2)
    issuedBtn.grid(row=0,column=3)

    backBtn = Button(btnFrame,text="BACK",font=("Arial", 15),padx=2,pady=2,command = lambda:newDashboard.showDashboard(btnFrame))
    backBtn.grid(row=2,column=0)

    btnFrame.mainloop()

def showBloodDetails(mainWindow,option):
    #mainWindow.destroy()
    #viewFrame = Tk()
    #viewFrame.geometry("1700x1700")
    viewFrame = LabelFrame(mainWindow,padx=2,pady=2)

    viewFrame.rowconfigure(0,weight=5)
    viewFrame.rowconfigure(1,weight=20)
    viewFrame.rowconfigure(2,weight=5)
    viewFrame.rowconfigure(3,weight=5)
    viewFrame.columnconfigure(0,weight=10)
    viewFrame.columnconfigure(1,weight=10)
    viewFrame.grid(row=1,column=1,sticky="nswe")
    searchFrame = Frame(viewFrame,padx=2,pady=2)
    searchFrame.grid(row=0,column=0,columnspan=15)
    for i in range(3):
        searchFrame.columnconfigure(i,weight=4)
    tabFrame = Frame(viewFrame,padx=2,pady=2)
    tabFrame.grid(row=1,column=0,columnspan=15,sticky="nswe")

    style = ttk.Style()
    #Pick a theme
    style.theme_use("clam")
    # Configure our treeview colors

    style.configure("Treeview",
	background="#D2D2D2",
	foreground="black",
	rowheight=25,
	fieldbackground="#D2D2D2",
    font = ("Arial", 10),
    anchor = "center"
	)
# Change selected color
    style.map('Treeview',
	background=[('selected', 'green')])

    tab = ttk.Treeview(tabFrame,show='headings',selectmode='none')

    scrollbar = ttk.Scrollbar(tabFrame, orient=VERTICAL, command=tab.yview)
    tab.configure(yscroll=scrollbar.set)
    scrollbar.grid(row=0, column=1, sticky='ns')

    tab.grid(row=0,column=0,sticky="NSWE")

    searchLabel = Label(searchFrame,text="Search by Blood Group  *", font=("Arial", 13))
    searchLabel.grid(row=0,column=0,sticky="W")

    bloodgroupList =['A +ve','B +ve','AB +ve','O +ve','A -ve','B -ve','AB -ve','O -ve']
    bloodgrpVar= StringVar()
    bloodgrpMenu = ttk.Combobox(searchFrame,textvariable=bloodgrpVar,values=bloodgroupList)
    bloodgrpMenu.grid(row=0,column=1,sticky="WE")

    totalLabel = Label(viewFrame,text="Total Units: ",font=("Arial", 15))
    valVar = StringVar()
    valVar.set("0")
    valLabel = Label(viewFrame,textvariable=valVar,font=("Arial", 15))
    totalLabel.grid(row=2,column=0,sticky="E")
    valLabel.grid(row=2,column=1,sticky="W")

    if option=='PENDING_TEST':
        columns = ('pktId','dname','Doc')
        tab.configure(column=columns)
        tab.heading('pktId', text="Packet_Id")
        tab.heading('dname', text="Donor Name")
        #tab.heading('bloodgrp', text="Blood group")
        tab.heading('Doc', text="Date Of Collection")



        totalVal = getrows(tab,option,columns)
        valVar.set(totalVal)
        searchBtn = Button(searchFrame,text="SEARCH",font=("Arial", 15),activebackground="green",state=DISABLED)
        searchBtn.grid(row=0,column=2,sticky="E")

    if option=='AVAILABLE':
        columns = ('pktId','dname','bloodgrp','Doc')
        tab.configure(column=columns)
        tab.heading('pktId', text="Packet_Id")
        tab.heading('dname', text="Donor Name")
        tab.heading('bloodgrp', text="Blood group")
        tab.heading('Doc', text="Date Of Collection")


        totalVal = getrows(tab,option,columns)
        valVar.set(totalVal)
        searchBtn = Button(searchFrame,text="SEARCH",font=("Arial", 15),activebackground="green",command= lambda: getSearchResult(tab,option,bloodgrpMenu.get(),valVar))
        searchBtn.grid(row=0,column=2,sticky="E")

    if option=='ISSUED':
        columns = ('pktId','rname','bloodgrp','doi')
        tab.configure(column=columns)
        tab.heading('pktId', text="Packet_Id")
        tab.heading('bloodgrp', text="Blood group")
        tab.heading('rname', text="Receiver Name")
        tab.heading('doi', text="Date Of Issue")



        totalVal = getrows(tab,option,columns)
        valVar.set(totalVal)
        searchBtn = Button(searchFrame,text="SEARCH",font=("Arial", 15),activebackground="green",command= lambda: getSearchResult(tab,option,bloodgrpMenu.get(),valVar))
        searchBtn.grid(row=0,column=2,sticky="E")

    if option == "WASTE BLOOD":

        columns = ('pktId','dname','bloodgrp','status')
        tab.configure(column=columns)
        tab.heading('pktId', text="Packet_Id")
        tab.heading('dname', text="Donor Name")
        tab.heading('bloodgrp', text="Blood group")
        tab.heading('status', text="Status")

        totalVal =getrows(tab,option,columns)
        valVar.set(totalVal)
        searchBtn = Button(searchFrame,text="SEARCH",font=("Arial", 15),activebackground="green",command= lambda: getSearchResult(tab,option,bloodgrpMenu.get(),valVar))
        searchBtn.grid(row=0,column=2,sticky="E")

def getrows(table,option,cols):

    #mycur = mydb.cursor()
    if option=="WASTE BLOOD":
        mycur = mydb.cursor()
        sql = '''select  bp.bloodpktId, CONCAT(u.firstname," ",u.lastname), CONCAT(bp.bloodgroup," ",bp.rhValue),bp.bloodStatus
                from blood_packet bp join user u on bp.userId=u.userId
                where bp.bloodStatus = 'TEST_FAILED' or bp.bloodStatus='EXPIRED'
                order by bp.dateOfCollection;'''
        mycur.execute(sql)
        data = mycur.fetchall()
        for i in data:
            table.insert("",END,values=i)

        mycur.close()
        return str(len(data))
    if option=="ISSUED":
        mycur = mydb.cursor()
        val ={'1':option}
        sql = '''select  bp.bloodpktId, CONCAT(u.firstname," ",u.lastname), CONCAT(bp.bloodgroup," ",bp.rhvalue),bp.dateOfIssue
                from blood_packet bp join user u on bp.recvId=u.userId
                where bp.bloodStatus = %(1)s
                order by bp.dateOfIssue;'''
        mycur.execute(sql,val)
        data = mycur.fetchall()
        for i in data:
            table.insert("",END,values=i)

        mycur.close()
        return str(len(data))
    if option=="PENDING_TEST":
        mycur = mydb.cursor()
        val= {'1':option}
        sql = '''select  bp.bloodpktId, CONCAT(u.firstname," ",u.lastname), bp.dateOfCollection
                from blood_packet bp join user u on bp.userId=u.userId
                where bp.bloodStatus = %(1)s

               ;'''
        mycur.execute(sql,val)
        data = mycur.fetchall()
        for i in data:
            table.insert("",END,values=i)

        mycur.close()
        return str(len(data))
    if option=='AVAILABLE':
        mycur = mydb.cursor()
        val= {"1":"AVAILABLE"}
        sql = '''select  bp.bloodpktId, CONCAT(u.firstname," ",u.lastname), CONCAT(bp.bloodgroup," ",bp.rhValue),bp.dateOfCollection
                from blood_packet bp join user u on bp.userId=u.userId
                where bp.bloodStatus = %(1)s

               ;'''
        mycur.execute(sql,val)
        data = mycur.fetchall()
        for i in data:
            table.insert("",END,values=i)

        mycur.close()
        return str(len(data))

def getSearchResult(table,option,filterOpt,unitsVal):
    for item in table.get_children():
      table.delete(item)
    bloodgrp, rh = filterOpt.split(" ")
    if option=="WASTE BLOOD":
        val = {"1":bloodgrp,"2":rh}
        mycur = mydb.cursor()
        sql = '''select  bp.bloodpktId, CONCAT(u.firstname," ",u.lastname), CONCAT(bp.bloodgroup," ",bp.rhvalue),bp.bloodStatus
                from blood_packet bp join user u on bp.userId=u.userId
                where (bp.bloodStatus = 'TEST_FAILED' or bp.bloodStatus='EXPIRED') and
                bp.bloodgroup = %(1)s and
                bp.rhValue = %(2)s

                order by bp.dateOfCollection;'''
        mycur.execute(sql,val)
        data = mycur.fetchall()
        for i in data:
            table.insert("",END,values=i)

        mycur.close()
        unitsVal.set(str(len(data)))
    if option=="ISSUED":
        mycur = mydb.cursor()
        val ={'1':option,"2":bloodgrp,"3":rh}
        sql = '''select  bp.bloodpktId, CONCAT(u.firstname," ",u.lastname), CONCAT(bp.bloodgroup," ",bp.rhvalue),bp.dateOfIssue
                from blood_packet bp join user u on bp.recvId=u.userId
                where bp.bloodStatus = %(1)s and
                bp.bloodgroup = %(2)s and
                bp.rhValue = %(3)s
                order by bp.dateOfIssue;'''
        mycur.execute(sql,val)
        data = mycur.fetchall()
        for i in data:
            table.insert("",END,values=i)

        mycur.close()
        unitsVal.set(str(len(data)))
    if option=="PENDING_TEST":
        mycur = mydb.cursor()
        val= {'1':option,"2":bloodgrp,"3":rh}
        sql = '''select  bp.bloodpktId, CONCAT(u.firstname," ",u.lastname), CONCAT(bp.bloodgroup," ",bp.rhvalue),bp.dateOfCollection
                from blood_packet bp join user u on bp.userId=u.userId
                where bp.bloodStatus = %(1)s and
                bp.bloodgroup = %(2)s and
                bp.rhValue = %(3)s

               ;'''
        mycur.execute(sql,val)
        data = mycur.fetchall()
        for i in data:
            table.insert("",END,values=i)

        mycur.close()
        unitsVal.set(str(len(data)))
    if option=='AVAILABLE':
        mycur = mydb.cursor()
        val= {"1":"AVAILABLE","2":bloodgrp,"3":rh}
        sql = '''select  bp.bloodpktId, CONCAT(u.firstname," ",u.lastname), CONCAT(bp.bloodgroup," ",bp.rhvalue),bp.dateOfCollection
                from blood_packet bp join user u on bp.userId=u.userId
                where bp.bloodStatus = %(1)s and
                bp.bloodgroup = %(2)s and
                bp.rhValue = %(3)s

               ;'''
        mycur.execute(sql,val)
        data = mycur.fetchall()
        for i in data:
            table.insert("",END,values=i)

        mycur.close()
        unitsVal.set(str(len(data)))













