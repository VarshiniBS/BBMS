# -*- coding: utf-8 -*-
"""
Created on Sun May 15 20:02:15 2022

@author: Home
"""

from tkinter import * #for gui
from tkinter import messagebox #for mesaage boxes
from newDashboard import *
import mysql.connector




 #connect to database
mydb = mysql.connector.connect(
        host="localhost",
        user="",
        password="",
        database = ""

    )


def adminLogin():





    #method to call when login button is clicked

    #creating a new window
    root = Tk()

    #specifying size of the window
    root.geometry("1900x1800")
    #title
    root.title("ABC BLOOD BANK")

    #creating a new frame
    frame =   Frame(root,padx=15,pady=15,bd=2,relief=RIDGE)
    frame.place(relx = 0.5, rely = 0.5, anchor = CENTER)
    #frame.grid_propagate(0)

    #creating heading,username and password labels
    heading = Label(frame,text="Admin Login",font=("Arial", 30),justify=CENTER)

    username = Label(frame,text="Login ID",font=("Arial", 15))
    password = Label(frame,text="Password",font=("Arial", 15))


    #placing them on the frame using grid method
    heading.grid(row=0,column=0,columnspan=4)

    username.grid(row=1,column=0,columnspan=2)
    password.grid(row=2,column=0,columnspan=2)



    #creating entry widgets for userid and password
    ubox =Entry(frame,borderwidth=3,font=("Arial", 10))
    pbox= Entry(frame,borderwidth=3,show="*")
    #placing them on screen
    ubox.grid(row=1,column=2,columnspan=2,padx=5,pady=10,ipadx=3,ipady=4)
    pbox.grid(row=2,column=2,columnspan=2,padx=5,pady=10,ipadx=3,ipady=4)

    #creating submit button and placing it on screen
    submit_btn = Button(frame,text="LOGIN",font=("Arial", 15),activebackground="green",command=lambda:loginClicked(ubox.get(),pbox.get(),root))
    submit_btn.grid(row=3,column=0,columnspan=2,padx=5,pady=10,sticky="w,e")






    root.mainloop()


def loginClicked(userId,password,frame):
    #create a cursor
    mycursor = mydb.cursor()
    if userId=="" :
        messagebox.showerror("Error","Please enter the user Id")
    if password=="":
        messagebox.showerror("Error","Please enter the password")
    if userId!="" and password!="":
        sql = """
        SELECT u.firstname, u.lastname
        FROM user u JOIN user_roles ur ON u.userid=ur.userId JOIN roles r ON ur.roleId=r.roleId
        WHERE r.roleName='Admin' AND u.loginid=%s AND u.login_pass=%s;
        """
        mycursor.execute(sql,(userId,password))
        data = mycursor.fetchone()
        if data==None:
            messagebox.showerror("Error","Login unsuccessful.\n Check if the id and password are typed correctly")

        else:
            messagebox.showinfo("Success","Login Successful")
            showDashboard(frame)
            mycursor.close()

def logoutFunc(dashboard):
    dashboard.destroy()
    adminLogin()
