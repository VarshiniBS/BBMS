# -*- coding: utf-8 -*-
"""
Created on Sun May 15 20:00:32 2022

@author: Home
"""

from Admin import *
adminLogin()
