# -*- coding: utf-8 -*-
"""
Created on Sun May 15 20:01:35 2022

@author: Home
"""

from tkinter import * #for gui
from tkinter import messagebox #for mesaage boxes
import mysql.connector
from userMod import *
import Admin
#from InventoryMod import *
#from TestingMod import *


def showDashboard(frame,data):
    frame.destroy()
    dashboard = Tk()
    dashboard.geometry("1900x1800")
    dashboard.title("Admin Dashboard")

    for i in range(3):
        dashboard.columnconfigure(i,weight=15)

    dashboard.rowconfigure(0,weight=1)
    dashboard.rowconfigure(1,weight=10)
    dashboard.rowconfigure(2,weight=10)

    welcomeLabel = Label(dashboard,text="Welcome "+data[0]+" "+data[1],font=("Arial", 15))
    welcomeLabel.grid(row=0,column=0,sticky="NSEW")

    userModBtns = LabelFrame(dashboard,padx=2,pady=2)
    inventoryModBtns =LabelFrame(dashboard,padx=2,pady=2)
    reportMod = LabelFrame(dashboard,padx=2,pady=2)

    userModBtns.grid(row=1,column=0,sticky="nswe",padx=10,pady=10)
    inventoryModBtns.grid(row=1,column=2,sticky="nswe",padx=10,pady=10)
    reportMod.grid(row=2,column=1,sticky="nswe",padx=10,pady=10)

    for i in range(3):
        userModBtns.rowconfigure(i,weight=5)
        inventoryModBtns.rowconfigure(i,weight=5)
        reportMod.rowconfigure(i,weight=5)

    userModBtns.columnconfigure(0,weight=20)
    inventoryModBtns.columnconfigure(0,weight=20)
    reportMod.columnconfigure(0,weight=20)

    newUserBtn = Button(userModBtns ,text="Add New User",font=("Arial", 10),padx=2,pady=2,width=15,command = lambda:addNewUser(dashboard,data))
    updateBtn = Button(userModBtns ,text="Update User Info",font=("Arial", 10),padx=2,pady=2,width=15,command= lambda:showUpdateInfoBtns(dashboard))
    allUsersBtn = Button(userModBtns ,text="All Users",font=("Arial", 10),padx=2,pady=2,width=15)

    newUserBtn.grid(row=0,column=0)
    updateBtn.grid(row=1,column=0,columnspan=2)
    allUsersBtn.grid(row=2,column=0,columnspan=2)

    addBloodBtn = Button(inventoryModBtns,text="Add To BloodStock",font=("Arial", 10),padx=2,pady=2,width=15,command = lambda:showAddToStockFrame(dashboard))
    viewInvBtn = Button(inventoryModBtns,text="View Inventory details ",font=("Arial", 10),padx=2,pady=2,width=15,command = lambda:showInventoryOptions(dashboard))
    issueBtn = Button(inventoryModBtns,text="Issue",font=("Arial", 10),padx=2,pady=2,width=15,command = lambda:showBloodggrpOptions(dashboard))

    addBloodBtn.grid(row=0,column=0,columnspan=2)
    viewInvBtn.grid(row=1,column=0,columnspan=2)
    issueBtn.grid(row=2,column=0,columnspan=2)

    setStatusBtn = Button(reportMod,text="set Test Status",font=("Arial", 10),padx=2,pady=2,width=15)
    fillReportBtn = Button(reportMod,text="Fill Test Report",font=("Arial", 10),padx=2,pady=2,width=15,command = lambda:showUntestedSample(dashboard))
    viewReportBtn = Button(reportMod,text="View Test Report",font=("Arial", 10),padx=2,pady=2,width=15)

    setStatusBtn.grid(row=0,column=0,columnspan=2)
    fillReportBtn.grid(row=1,column=0,columnspan=2)
    viewReportBtn.grid(row=2,column=0,columnspan=2)

    logoutBtn = Button(dashboard,text="Logout",font=("Arial", 15),padx=2,pady=2,command = lambda:Admin.logoutFunc(dashboard))
    logoutBtn.grid(row=0,column=2)

    dashboard.mainloop()


