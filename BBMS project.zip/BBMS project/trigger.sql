delimiter &&
create trigger setBloodStatus 
after update on bloodtest  for each row
begin
if new.teststatus = 'PASS' then
update blood_packet bp
set bloodStatus = 'AVAILABLE'
where bp.bloodpktId = old.bloodpktId ;
end if;
if new.teststatus = 'FAIL' then
update blood_packet bp
set bloodStatus = 'TEST_FAILED'
where bp.bloodpktId = old.bloodpktId;
end if;
end &&

